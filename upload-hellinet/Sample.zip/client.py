import random

MAP_DETAIL_LENGTH = 7

game_map = None

def read_map():
	nodes_count = int(input())
	
	if map == None:
		map = [[int(input()) for j in range(MAP_DETAIL_LENGTH)] for i in range(nodes_count)]
	

def main(client_id):
	inp = ''
	while inp != 'shutdown':
		inp = input()
		
		if inp == 'turn':
			read_map()
		
		source_id = -1
		dest_id = -1
		
		# decide whether to attack or not. 
		# if you decided to attack, place destination id and source id in two variables dest_id and source_id
		# attack will be lunched in order : source -> dest
		# if you decided not to attack set source_id to be -1
		# write your code here ....
		
		
		# write your code here ....
		
		print(source_id, dest_id)

if __name__ == "__main__":
	id = 1
	main(id)
