#include <iostream>
#include <string>
#include <time.h>

using namespace std;
const int MAP_DETAIL_LENGTH = 7;

int** map = nullptr;
int nodes_count = 0;

void read_map()
{
	cin >> nodes_count;
	bool must_alloc = false;
	
	if (map == nullptr)
	{
		map = new int*[nodes_count];
		must_alloc = true;
	}
	for (int i = 0; i < nodes_count; i++)
	{
		if (must_alloc)
			map[i] = new int[MAP_DETAIL_LENGTH];
		for (int j = 0; j < MAP_DETAIL_LENGTH; j++)
		{
			cin >> map[i][j];
		}
	}
}

int main(int argc, char** argv)
{
	srand(time(NULL));

	int client_id = 0;
	if (argc > 1)
		 client_id = atoi(argv[1]);


	string input = "";
	while (input != "shutdown")
	{
		cin >> input;
		if (input == "turn")
		{
			read_map();
			cout << map[0][6] << endl;
		}	
		int source_id = 0, dest_id = 0;
		
		// you have  a map which containes details you know about the map
		// number of nodes is stored in variable nodes_count
		// map is a 2d array which has 'nodes_count' rows and each row representing a node in map
		// each row contaies 7 columns and they have information in this order
		// node_id, owner_id, position_x, position_y, factor, soldier_count, max_value
		// node_id is the node_id
		// owner id shows ho is the owner of this node. your id is stored in variable client_id if owner id is equal to client id, so this node is yours if its zero, its for no one and else its for your oponent
		// position_x and position_y holds the position of nodes
		// factor shows that how many soldiers are added to that node each turn. note that a node which is for no one, dosent populate any soldiers
		// soldiers count shows how many soldiers is in that node. if the node is not yours, you cant see soldiers count and it is -1 for you
		// max value shows how many soldier can placed in that node at max
		// decide whether to attack or not. 
		// if you decided to attack, place destination id and source id in two variables dest_id and source_id
		// attack will be lunched in order : source -> dest
		// if you decided not to attack set source_id to be 0
		// pay attentation. you must return the id of nodes not array index.
		// write your code here ....
		
	
		// write your code here ....
		
		cout << source_id << " " << dest_id << endl;
	}
}